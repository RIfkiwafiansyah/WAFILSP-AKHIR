<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
    <link rel="stylesheet" href="../style/admin.css">
</head>
<body>
    
    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="product.php">Produk</a>
        <a href="transaksi.php">Transaksi</a>
        <a href="verifikasi_transaksi.php">Verifikasi Transaksi</a>
        <a href="../logout.php">Logout</a>
    </div>

</body>
</html>